import os.path
import os
import random

userdatapassword = "userpassword.user"
usernamedata = "logincredit.user"
adminuser = "adminlogincredit.admin"
adminuserpassword = "adminuserpassword.admin"
userloggedin = False
adminloggedin = False

def loginuser():
    check_file_user = os.path.isfile(usernamedata)
    if check_file_user == True:
        usernamelogin = input("Enter your username: ")
        with open(usernamedata, "r") as check_user_name:
            usernamelogindata = check_user_name.read()
            if usernamelogin in usernamelogindata:
                enterpassword()
            else:
                print("Username not found!")
                loginuser()
    else:
        file_not_found()



def enterpassword():
    check_file_password = os.path.isfile(userdatapassword)
    if check_file_password == True:
        password = input("Enter password: ")
        with open(userdatapassword, "r") as check_password:
            getpassowrdata = check_password.read()
            if password in getpassowrdata:
                global userloggedin
                userloggedin = True
            else:
                print("Incorrect password!")
                enterpassword()
    if userloggedin == True:
        options()
    else:
        file_not_found()


def options():
    with open(usernamedata, "r") as username_logged_in:
        username = username_logged_in.read()
    username_logged_in.close()
    os.system("cls")
    print("Hello " + str(username))
    print("Pick your options below.")
    print("1) Restart Explorer") 
    print("2) Open Command Prompt")
    print("3) Run Task Manager")
    print("4) Calculator")
    print("5) Open Notepad")
    print("6) Password Picker")
    print("7) Open Google")
    print("8) Shutdown")
    print("9) Restart")
    print("10) Logoff")
    print("11) Cancel Shutdown")
    print("12) Bit to Value")
    print("13) Check Age")
    print("14) Random Numbers Generator")
    print("15) User Logout")
    app_choice()



def app_choice():
    choiceinput = input("Pick your option: ")
    if choiceinput == "1":
        rexp()
    elif choiceinput == "2":
        os.system("start")
        options()
    elif choiceinput == "3":
        os.system("start taskmgr.exe")
        options()
    elif choiceinput == "4":
        calculator()
    elif choiceinput == "5":
        os.system("start notepad.exe")
        options()
    elif choiceinput == "6":
        passwordpicker()
    elif choiceinput == "7":
        os.system("start https://google.com")
        options()
    elif choiceinput == "8":
        print("Your system will shutdown in 1 minutes.")
        os.system("shutdown -s -t 60")
        os.system("pause")
        options()
    elif choiceinput == "9":
        print("Your system will restart in 1 minutes.")
        os.system("shutdown -r -t 60")
        os.system("pause")
        options()
    elif choiceinput == "10":
        os.system("shutdown -l")
    elif choiceinput == "11":
        print("Shutdown cancelled.")
        os.system("shutdown -a")
        os.system("pause")
        options()
    elif choiceinput == "12":
        bitinput()
    elif choiceinput == "13":
        age()
    elif choiceinput == "14":
        count()
    elif choiceinput == "15":
        choice()
    else:
        print("Invaild option! Try again.")
        os.system("pause")
        options()

def resetage():
    restart = input("Try again? (y/n) ")
    if restart == "y":
        age()
    elif restart == "n":
        options()
    else:
        options()

def count():
    os.system("cls")
    times = int(input("How many random numbers to generate?: "))
    rangenum = int(input("What is the number to range from 0?: "))
    print("Here is your numbers: ")
    for nums in range(0, int(times)):
        nums = random.randint(0,int(rangenum))
        print(nums)
    reset = input("Generate again? (y/n)")
    if reset == "y":
        count()
    elif reset == "n":
        options()
    else:
        options()

def age():
    age = int(input("How old are you?: "))
    if age < 5:
        print("You are the baby")
        resetage()
    elif age == 5:
        print("You start to chlidren")
        resetage()
    elif 10 > age > 5:
        print("You are the chlidren")
        resetage()
    elif age == 10:
        print("You start as high school / university student")
        resetage()
    elif 18 > age > 10:
        print("You are the high school / university student")
        resetage()
    elif age == 18:
        print("You start as adult")
        resetage()
    elif 18 < age < 30:
        print("You are the adult")
        resetage()
    elif age == 30:
        print("You start as middle adult")
        resetage()
    elif 30 < age < 60:
        print("You are the middle adult")
        resetage()
    elif age == 60:
        print("You start as old")
        resetage()
    elif 60 < age < 80:
        print("You are old")
        resetage()
    else:
        print("Unkhown number or age more than 80 (If you type this, you are oldest.)")
        resetage()

def bitinput():
    os.system("cls")
    listvalue = 1
    value = 0
    getbit = int(input("What is the number of bit you want to get value (Will pick random character 0 or 1)?: "))
    for bit in range(0, int(getbit)):
        bit = random.randint(0,1)
        listvalue = listvalue * 2
        print(str(bit) + " = " + str(listvalue) + " value.")
        if bit == 1:
            value = value + listvalue    
        else:
            pass
    print("Value number: " + str(value))
    reset()



def reset():
    reset = input("Try again? (y/n) ")
    if reset == "y":
        bitinput()
    elif reset == "n":
        options()
    else:
        options()




def passwordpicker():
    os.system("cls")
    wordpass = ["rickroll", "me", "python", "py", "you"]
    wordpass2 = ["random", "microsoft", "windows"]
    wordpass3 = ["tommyinit", "pewdie", "pewdiepie", "mrbeast", "youtube", "play"]
    number = random.randint(0,1000)
    number2 = random.randint(0,1000)
    word = random.choice(wordpass)
    word2 = random.choice(wordpass2)
    word3 = random.choice(wordpass3)
    password = str(word) + str(number) + str(word2) + str(word3) + str(number2)
    print("Your password is: " + str(password))
    back = input("Try again? (y/n) ")
    if back == "y":
        passwordpicker()
    elif back == "n":
        options()
    else:
        options()



def rexp():
    os.system("taskkill /f /im explorer.exe")
    os.system("start explorer.exe")
    options()



def calculator():
    # Sources from: https://www.programiz.com/python-programming/examples/calculator
    # Copying sources, and fixing code.
    os.system("cls")
    # Program make a simple calculator

    # This function adds two numbers
    def add(x, y):
        return x + y

    # This function subtracts two numbers
    def subtract(x, y):
        return x - y

    # This function multiplies two numbers
    def multiply(x, y):
        return x * y

    # This function divides two numbers
    def divide(x, y):
        return x / y


    print("Select your operation.")
    print("1.Add")
    print("2.Subtract")
    print("3.Multiply")
    print("4.Divide")

    while True:
        # take input from the user
        choice = input("Enter choice (1/2/3/4): ")

        # check if choice is one of the four options
        if choice in ('1', '2', '3', '4'):
            num1 = float(input("Enter first number: "))
            num2 = float(input("Enter second number: "))

            if choice == '1':
                print(num1, "+", num2, "=", add(num1, num2))

            elif choice == '2':
                print(num1, "-", num2, "=", subtract(num1, num2))

            elif choice == '3':
                print(num1, "*", num2, "=", multiply(num1, num2))

            elif choice == '4':
                print(num1, "/", num2, "=", divide(num1, num2))
            
            # check if user wants another calculation
            # break the while loop if answer is no
            next_calculation = input("Let's do next calculation? (y/n): ")
            if next_calculation == "y":
                calculator()
            if next_calculation == "n":
                options()
        
        else:
            print("Invalid input. Try again.")


def file_not_found():
    startcreate = input("No user data file found! Create user? (y/n): ")
    if startcreate == "y":
        create_user()
    else:
        quit()


def password_create():
    userpassword = input("Enter password: ")
    check_file = os.path.isfile(userdatapassword)
    if check_file == True:
        with open(userdatapassword, "r") as datauserpassword:
            password_data = datauserpassword.read()
        if userpassword in password_data:
            print("This password is taken! Try again")
            password_create()
        else:
            create_password(userpassword)
    else:
        create_password(userpassword)

def create_password(userpassword):
    with open(userdatapassword, "w") as datauserpassword2:
        datauserpassword2.write(userpassword + "\n")
        datauserpassword2.close()
        choice()


def create_user():
    username = input("Enter username: ")
    check_file_2 = os.path.isfile(usernamedata)
    if check_file_2 == True:
        with open(usernamedata, "r") as userdataname:
            username_data = userdataname.read()
        if username in username_data:
            print("This name is taken! Try again!")
            userdataname.close()
            create_user()
        else:
            accountuser(username)
    else:
        accountuser(username)

def accountuser(username):
    with open(usernamedata, "w") as userdatanamewrite:
        userdatanamewrite.write(username + "\n")
    userdatanamewrite.close()
    password_create()


def create_admin_user():
    adminusername = input("Enter username: ")
    admin_check_file = os.path.isfile(adminuser)
    if admin_check_file == True:
        with open(adminuser, "r") as adminuserdataname:
            username_data = adminuserdataname.read()
        if adminusername in username_data:
            print("This name is taken! Try again!")
            adminuserdataname.close()
            create_admin_user()
        else:
            admin_accountuser(adminusername)
    else:
        admin_accountuser(adminusername)

def admin_accountuser(adminusername):
    with open(adminuser, "w") as adminuserdataname2:
        adminuserdataname2.write(adminusername + "\n")
    adminuserdataname2.close()
    admin_password_create()

def admin_password_create():
    setadminuserpassword = input("Enter password: ")
    admin_check_file_2 = os.path.isfile(adminuserpassword)
    if admin_check_file_2 == True:
        with open(adminuserpassword, "r") as dataadminuserpassword:
            admin_password_data = dataadminuserpassword.read()
        if setadminuserpassword in admin_password_data:
            print("This password is taken! Try again")
            admin_password_create()
        else:
            admin_create_password(setadminuserpassword)
    else:
        admin_create_password(setadminuserpassword)

def admin_create_password(setadminuserpassword):
    with open(adminuserpassword, "w") as admin_userpasswordset:
        admin_userpasswordset.write(setadminuserpassword + "\n")
        admin_userpasswordset.close()
        choice()


def loginadminuser():
    check_file_user = os.path.isfile(adminuser)
    if check_file_user == True:
        usernamelogin = input("Enter your username: ")
        with open(adminuser, "r") as check_user_name:
            usernamelogindata = check_user_name.read()
            if usernamelogin in usernamelogindata:
                adminenterpassword()
            else:
                print("Username not found!")
                loginuser()
    else:
        file_not_found()



def adminenterpassword():
    check_file_password = os.path.isfile(adminuserpassword)
    if check_file_password == True:
        password = input("Enter password: ")
        with open(adminuserpassword, "r") as check_password:
            getpassowrdata = check_password.read()
            if password in getpassowrdata:
                adminloggedin = True
            else:
                print("Incorrect password!")
                enterpassword()
    if adminloggedin == True:
        console()
    else:
        admin_file_not_found()


def admin_file_not_found():
    startcreate = input("No admin user data file found! Create user? (y/n): ")
    if startcreate == "y":
        create_admin_user()
    else:
        quit()


def console():
    with open(adminuser, "r") as admin_check:
        adminname = admin_check.read()
    print("Hello " + str(adminname))
    print("Welcome to the console!")
    os.system("echo Today is %date%")
    print("Type help to open help")
    start()

def resetuser():
    userfile = os.path.isfile(usernamedata)
    userpassfile = os.path.isfile(userdatapassword)
    if userfile == True and userpassfile == True:
        with open(usernamedata, "r") as remove:
            remove.close()
        os.remove(usernamedata)
        os.remove(userdatapassword)
        print("Reset successfully!")
        start()
    else:
        print("File not found!")
        start()


def clear():
    os.system("cls")
    start()

def helpcmd():
        print("Type clearscreen to clear screen.")
        print("Type quit to quit the console")
        print("Type help to open help")
        print("Type date to show date")
        print("Type version to show version")
        print("Type resetuser to reset normal user system.")
        print("Type logoff to logoff admin user")
        start()

def start():
    options = input(">>> ")
    if options == "help":
        helpcmd()
    if options == "clearscreen":
        clear()
    if options == "date":
        os.system("echo Today is %date%")
        start()
    if options == "version":
        os.system("ver")
        start()
    if options == "resetuser":
        resetuser()
    if options == "logoff":
        choice()
    if options == "":
        start()
    else:
        print("Error!")
        start()


def choice():
    print("Pick your option")
    print("1) Login")
    print("2) Create user")
    print("3) Quit")
    choices = ["1", "2", "3"]
    options = input("Enter your options: ")
    if options in choices:
        if options == "1":
            print("Pick your user type.")
            print("1) Normal user")
            print("2) Admin user")
            user_type_choice = input("Pick your options: ")
            if user_type_choice == "1":
                loginuser()
            if user_type_choice == "2":
                loginadminuser()
            else:
                choice()
        if options == "2":
            print("Pick your user type.")
            print("1) Normal user")
            print("2) Admin user")
            user_type_choice = input("Pick your options: ")
            if user_type_choice == "1":
                create_user()
            if user_type_choice == "2":
                create_admin_user()
            else:
                choice()
            
        if options == "3":
            quit()
    else:
        print("Error!")
        os.system("pause")
        os.system("cls")
        choice()



choice()